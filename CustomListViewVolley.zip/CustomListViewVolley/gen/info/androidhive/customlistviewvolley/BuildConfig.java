/** Automatically generated file. DO NOT MODIFY */
package info.androidhive.customlistviewvolley;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}